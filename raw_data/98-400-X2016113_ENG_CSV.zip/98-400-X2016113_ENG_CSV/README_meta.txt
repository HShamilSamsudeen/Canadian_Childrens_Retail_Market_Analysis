﻿This zipped file contains the following files:

*_meta.txt – contains the metadata for the data file, including general information, geography notes, definitions and footnotes.

*CSV_data.csv – contains the data in a comma delimited format
or
*TAB_data.csv – contains the data in a tab delimited format.

Geo_starting_row_CSV.csv
or
Geo_starting_row_TAB.csv
Contains the starting row number for each geography in the data file. Due to the number of records in the download file, some software packages might not be able to import the Census Profile for all geographies included in the selected geographic level. To assist users in finding data for their geographic area(s) of interest, this file shows the starting row number for each geography included in the data file. Some software packages allow you to specify a starting row number when importing the data. For example, the Text Import Wizard within Microsoft Excel includes an option to 'Start import at row:', and the Import Data Wizard in SAS includes an option for 'Data records start at record number:'.

Data file record layout (column headings):

"CENSUS_YEAR"
"GEO_CODE (POR)"
"GEO_LEVEL"
"GEO_NAME"
"GNR"
"DATA_QUALITY_FLAG"
"ALT_GEO_CODE"
"DIM: Year (2)"
"Member ID: Year (2)"
"Notes: Year (2)"
"DIM: Age (9)"
"Member ID: Age (9)"
"Notes: Age (9)"
"DIM: Sex (3)"
"Member ID: Sex (3)"
"Notes: Sex (3)"
"DIM: Income sources and taxes (16)"
"Member ID: Income sources and taxes (16)"
"Notes: Income sources and taxes (16)"
"Dim: Income statistics (4): Member ID: [1]: Total - Population aged 15 years and over"
"Dim: Income statistics (4): Member ID: [2]: With an amount"
"Dim: Income statistics (4): Member ID: [3]: Percentage with an amount (%)"
"Dim: Income statistics (4): Member ID: [4]: Median amount ($) (Note: 19)"